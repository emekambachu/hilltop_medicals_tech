<?php $__env->startSection('title'); ?>
    Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <header class="header-bottom-4">
        <img src="<?php echo e(asset('main/slides/slide1.jpg')); ?>">
        <div class="header-bottom-4__bg">
            <div class="icon">
                <img src="<?php echo e(asset('main/images/banner/banner-shape.png')); ?>">
            </div>
        </div>
        <div class="container">
            <h1 class="section-title">Services</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Services</li>
            </ol>
        </div>
    </header>

    <section class="departments-3 main-blog">
        <div class="main-blog__bg">
            <div class="icon">
                <img src="<?php echo e(asset('main/images/png-shapes/form-shape.png')); ?>">
            </div>
            <div class="icon">
                <img src="<?php echo e(asset('main/images/png-shapes/specialists__left-bottom-shape.png')); ?>">
            </div>
        </div>
        <div class="container">
            <div class="departments-3__items">

                <a href="" class="item">
                    <div class="img">
                        <img src="<?php echo e(asset('main/medical/central_c_air_compact_piston_15.jpg')); ?>">
                    </div>
                    <h1 class="title">Medical Supplies</h1>
                    <p class="text">We are the information backbone for most of the largest integrated health care technologies.</p>
                </a>

                <a href="" class="item">
                    <div class="img">
                        <img src="<?php echo e(asset('main/medical/hospital-infusion-pump-500x500.jpg')); ?>">
                    </div>
                    <h1 class="title">Logistics</h1>
                    <p class="text">With our reliable logistics services, your products and mdical apliances are delivered at your doorstep</p>
                </a>

                <a href="" class="item">
                    <div class="img">
                        <img src="<?php echo e(asset('main/medical/hospital-stretcher-500x500.jpg')); ?>">
                    </div>
                    <h1 class="title">Care Management</h1>
                    <p class="text">Identify outreach and care gaps opportunities with custom patient cohorts across hundreds of clinical and decision support fields.</p>
                </a>

                <a href="" class="item">
                    <div class="img">
                        <img src="<?php echo e(asset('main/Healthcare/endoscopy-equipment-500x500.jpg')); ?>">
                    </div>
                    <h1 class="title">Health Diagnostics</h1>
                    <p class="text">Improve health performance with our analytics technologies provide greater flexibility to analyze raw data so you can be more efficient and focus on practice profitabilit.</p>
                </a>
                <a href="" class="item">
                    <div class="img">
                        <img src="<?php echo e(asset('main/Healthcare/surgical microscope1.jpg')); ?>">
                    </div>
                    <h1 class="title">24 Hours Professional Services</h1>
                    <p class="text">You get designated 24/7 support, system monitoring, and regular check-ups to ensure your long-term success and improvement.</p>
                </a>

                <a href="" class="item">
                    <div class="img">
                        <img src="<?php echo e(asset('main/Healthcare/ultrasound_machine.jpg')); ?>">
                    </div>
                    <h1 class="title">Technology Consultation</h1>
                    <p class="text">Common tasks are streamlined to get the job done fast. Our highly experienced staffs keep you abreast of further developments and guidiance.</p>
                </a>

            </div>
        </div>
    </section>

    <section class="medical-center-2" >
        <div class="container">
            <div class="img">
                <img src="<?php echo e(asset('main/home/h_medical.jpg')); ?>">
            </div>
            <div class="content">
                <p class="text">We offer specialized service for maintenance, repairs and calibration of a wide range of laboratory, hospital, neonatal and veterinary equipment. We wish to bring complete satisfaction through our products, people and services we offer, to ensure our clients are empowered to make the best possible decisions in their field of expertise.</p>
                <p>
                    Our Research expands patient access to groundbreaking clinical trials. These trials pave the way for new forms of prevention, diagnosis and treatment. OHRI welcomes industry-sponsored research in partnership with drug and device companies looking to test their investigational products at a large facility associated with excellent clinicians.<br>
                    Academic research focuses on educating and training our physicians and clinicians to develop and execute scholarly projects that enhance their skills, knowledge and leadership in advancing healthcare. OhioHealth also provides an ideal setting for federal and foundation funded research.
                </p>

            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\hilltopmedicalstech\resources\views/services.blade.php ENDPATH**/ ?>